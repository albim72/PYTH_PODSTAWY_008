from __future__ import annotations

from dataclasses import dataclass

@dataclass
class Point:
    x: float
    y: float = 0.0

    def __post_init__(self) -> None:
        try:
            self.x = float(self.x)
            self.y = float(self.y)
        except (TypeError, ValueError) as e:
            raise ValueError("Point coordinates must be numeric.") from e

    def __repr__(self) -> str:
        return f"Point(x={self.x:.3f}, y={self.y:.3f})"
