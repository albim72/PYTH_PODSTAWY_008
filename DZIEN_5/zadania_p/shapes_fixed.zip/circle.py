from __future__ import annotations

import math
from typing import Dict, Any

from point import Point
from shape import Shape

class Circle(Shape):
    def __init__(self, center: Point, radius: float):
        if not isinstance(center, Point):
            raise TypeError("center must be a Point instance")
        try:
            radius = float(radius)
        except (TypeError, ValueError) as e:
            raise ValueError("radius must be numeric") from e
        if radius <= 0:
            raise ValueError("radius must be > 0")

        self.name = "circle"
        self.center = center
        self.radius = radius

    def area(self) -> float:
        return math.pi * (self.radius ** 2)

    def perimeter(self) -> float:
        return 2.0 * math.pi * self.radius

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.name,
            "center": {"x": self.center.x, "y": self.center.y},
            "radius": self.radius,
            "area": self.area(),
            "perimeter": self.perimeter(),
        }

    def __repr__(self) -> str:
        return f"Circle(center={self.center!r}, radius={self.radius:.3f})"
