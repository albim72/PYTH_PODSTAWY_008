from __future__ import annotations

import json
from typing import List

from point import Point
from circle import Circle
from shape import Shape

def save_to_json(shapes: List[Shape], path: str) -> None:
    payload = [s.to_dict() for s in shapes]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

def main() -> None:
    print("== SHAPES (fixed, 4 modules) ==")

    # Example objects
    p = Point(0, 0)
    c = Circle(p, 10)

    print("Center:", p)
    print("Circle:", c)
    print(f"Area: {c.area():.4f}")
    print(f"Perimeter: {c.perimeter():.4f}")

    save_to_json([c], "shapes.json")
    print("Saved: shapes.json")

if __name__ == "__main__":
    main()
