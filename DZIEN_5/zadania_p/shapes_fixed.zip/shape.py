from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Any

class Shape(ABC):
    name: str

    @abstractmethod
    def area(self) -> float:
        """Return area as a float."""

    @abstractmethod
    def perimeter(self) -> float:
        """Return perimeter (circumference) as a float."""

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable dictionary representation."""
