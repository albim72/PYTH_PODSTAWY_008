from __future__ import annotations

def format_money(x: float) -> str:
    return f"{x:.2f}"
