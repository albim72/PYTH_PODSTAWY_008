from __future__ import annotations
from typing import Dict, Iterable
from uuid import UUID
from ..domain.order import Order

class InMemoryOrderRepository:
    def __init__(self) -> None:
        self._db: Dict[UUID, Order] = {}

    def save(self, order: Order) -> None:
        self._db[order.id] = order

    def get(self, order_id: UUID) -> Order:
        try:
            return self._db[order_id]
        except KeyError:
            raise KeyError("Order not found")

    def list_all(self) -> Iterable[Order]:
        return list(self._db.values())
