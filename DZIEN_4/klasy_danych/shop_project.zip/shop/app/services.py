from __future__ import annotations
from dataclasses import replace
from ..domain.order import Order
from ..domain.cart import CartItem
from ..domain.customer import Customer
from .repository import InMemoryOrderRepository

class OrderService:
    def __init__(self, repo: InMemoryOrderRepository) -> None:
        self.repo = repo

    def create_order(self, customer: Customer) -> Order:
        order = Order(customer=customer)
        self.repo.save(order)
        return order

    def add_line(self, order_id, item: CartItem) -> Order:
        order = self.repo.get(order_id)
        order.add_item(item)
        self.repo.save(order)
        return order

    def apply_cart_discount(self, order_id, pct: float) -> Order:
        if not (0.0 <= pct < 1.0):
            raise ValueError("pct in [0,1)")
        order = self.repo.get(order_id)
        order._ensure_draft()
        order.items = [replace(it, discount_pct=min(0.99, it.discount_pct + pct)) for it in order.items]
        order._recalc()
        self.repo.save(order)
        return order

    def confirm(self, order_id) -> Order:
        order = self.repo.get(order_id)
        order.confirm()
        self.repo.save(order)
        return order
