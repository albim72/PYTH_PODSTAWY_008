from __future__ import annotations
from uuid import uuid4
from ..domain.address import Address
from ..domain.customer import Customer
from ..domain.product import Product
from ..domain.cart import CartItem
from ..app.repository import InMemoryOrderRepository
from ..app.services import OrderService
from ..utils.money import format_money

def demo() -> None:
    addr = Address("Królewska 10", "Warszawa")
    cust = Customer(id=uuid4(), name="Marcin Albiniak", email="marcin@example.com", address=addr)

    p_book = Product(sku="B-001", name="AI in Practice", price=120.0, vat=0.05)
    p_head = Product(sku="E-777", name="Headphones Pro", price=299.99)

    repo = InMemoryOrderRepository()
    svc = OrderService(repo)

    order = svc.create_order(cust)
    svc.add_line(order.id, CartItem(product=p_book, qty=2, discount_pct=0.10))
    svc.add_line(order.id, CartItem(product=p_head, qty=1))
    svc.apply_cart_discount(order.id, 0.05)
    order = repo.get(order.id)
    print("Total NET  :", format_money(order.total_net))
    print("Total GROSS:", format_money(order.total_gross))
    svc.confirm(order.id)
    print("Status:", order.status.name)

if __name__ == "__main__":
    demo()
