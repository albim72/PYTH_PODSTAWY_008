from __future__ import annotations
from dataclasses import dataclass, replace

@dataclass(slots=True)
class CartItem:
    product: "Product"   # forward reference
    qty: int
    discount_pct: float = 0.0

    def __post_init__(self):
        if self.qty < 1:
            raise ValueError("qty >= 1")
        if not (0.0 <= self.discount_pct < 1.0):
            raise ValueError("discount_pct in [0,1)")

    @property
    def net_unit(self) -> float:
        return self.product.price * (1.0 - self.discount_pct)

    @property
    def gross_unit(self) -> float:
        return self.net_unit * (1.0 + self.product.vat)

    @property
    def line_total_net(self) -> float:
        return self.net_unit * self.qty

    @property
    def line_total_gross(self) -> float:
        return self.gross_unit * self.qty

    def with_qty(self, qty: int) -> "CartItem":
        return replace(self, qty=qty)

from .product import Product  # for runtime availability if needed
