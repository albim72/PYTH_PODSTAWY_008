from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class Address:
    street: str
    city: str
    country: str = "PL"

    def pretty(self) -> str:
        return f"{self.street}, {self.city}, {self.country}"
