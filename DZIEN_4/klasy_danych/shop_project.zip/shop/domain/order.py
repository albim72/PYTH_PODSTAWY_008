from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum, auto
from typing import List, Dict
from uuid import UUID, uuid4
from .customer import Customer
from .cart import CartItem

class OrderStatus(Enum):
    DRAFT = auto()
    CONFIRMED = auto()
    CANCELLED = auto()

@dataclass(slots=True)
class Order:
    customer: Customer
    items: List[CartItem] = field(default_factory=list)
    status: OrderStatus = field(default=OrderStatus.DRAFT)
    id: UUID = field(default_factory=uuid4, init=False)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc), init=False)
    _total_net: float = field(default=0.0, init=False, repr=False)
    _total_gross: float = field(default=0.0, init=False, repr=False)

    def add_item(self, item: CartItem) -> None:
        self._ensure_draft()
        self.items.append(item)
        self._recalc()

    def remove_by_sku(self, sku: str) -> None:
        self._ensure_draft()
        before = len(self.items)
        self.items = [i for i in self.items if i.product.sku != sku]
        if len(self.items) == before:
            raise KeyError(f"Item with SKU {sku} not found")
        self._recalc()

    def change_qty(self, sku: str, qty: int) -> None:
        self._ensure_draft()
        found = False
        for idx, it in enumerate(self.items):
            if it.product.sku == sku:
                self.items[idx] = it.with_qty(qty)
                found = True
                break
        if not found:
            raise KeyError(f"SKU {sku} not found")
        self._recalc()

    def confirm(self) -> None:
        self._ensure_draft()
        if not self.items:
            raise ValueError("Cannot confirm empty order")
        self.status = OrderStatus.CONFIRMED

    def cancel(self) -> None:
        self.status = OrderStatus.CANCELLED

    @property
    def total_net(self) -> float:
        return round(self._total_net, 2)

    @property
    def total_gross(self) -> float:
        return round(self._total_gross, 2)

    def _recalc(self) -> None:
        self._total_net = sum(i.line_total_net for i in self.items)
        self._total_gross = sum(i.line_total_gross for i in self.items)

    def _ensure_draft(self) -> None:
        if self.status is not OrderStatus.DRAFT:
            raise RuntimeError("Order not editable outside DRAFT")

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["id"] = str(self.id)
        d["created_at"] = self.created_at.isoformat()
        d["status"] = self.status.name
        d["total_net"] = self.total_net
        d["total_gross"] = self.total_gross
        return d
