from __future__ import annotations
from dataclasses import dataclass

@dataclass(order=True, frozen=True, slots=True)
class Product:
    sku: str
    name: str
    price: float        # net
    vat: float = 0.23   # default VAT

    def __post_init__(self):
        if self.price < 0:
            raise ValueError("price >= 0")
        if not (0.0 <= self.vat < 1.0):
            raise ValueError("vat in [0,1)")
