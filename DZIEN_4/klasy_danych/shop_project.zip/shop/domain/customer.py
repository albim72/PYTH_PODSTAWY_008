from __future__ import annotations
from dataclasses import dataclass
from uuid import UUID
from .address import Address

@dataclass(frozen=True, slots=True)
class Customer:
    id: UUID
    name: str
    email: str
    address: Address

    def __post_init__(self):
        if "@" not in self.email:
            raise ValueError("Invalid email")
