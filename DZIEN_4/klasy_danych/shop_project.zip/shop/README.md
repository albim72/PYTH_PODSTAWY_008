# Shop Mini-Project (Modules + dataclasses)

## Structure

```
shop/
├─ domain/ (dataclasses models)
├─ app/     (repository, services)
├─ cli/     (demo entrypoint)
└─ utils/   (helpers)
```

## Run demo

From the parent directory:

```bash
python -m shop.cli.main
```

Requires Python 3.11+.
