# -*- coding: utf-8 -*-
"""
models.py
Modele pozycji bibliotecznych: klasy abstrakcyjne i dziedziczenie.
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass

@dataclass
class PozycjaBiblioteczna(ABC):
    tytul: str
    autor: str
    rok_wydania: int

    @abstractmethod
    def info(self) -> str:
        """Zwraca opis pozycji w postaci jednego wiersza."""
        raise NotImplementedError

@dataclass
class Ksiazka(PozycjaBiblioteczna):
    gatunek: str

    def info(self) -> str:
        return f"{self.tytul} - {self.autor} ({self.rok_wydania}), gatunek: {self.gatunek}"

@dataclass
class Czasopismo(PozycjaBiblioteczna):
    numer: str

    def info(self) -> str:
        return f"{self.tytul} - {self.autor} ({self.rok_wydania}), numer: {self.numer}"
