# System biblioteczny (zadanie podsumowujące)

Prosty system biblioteczny w Pythonie podzielony na moduły, wykorzystujący klasy abstrakcyjne.

## Struktura
```
.
├── biblioteka.py
├── models.py
└── main.py
```

## Uruchomienie
```bash
python3 main.py
```

## Funkcje
- Dodawanie książek oraz czasopism
- Wypisywanie wszystkich pozycji
- Wyszukiwanie po tytule (case-insensitive)
