# -*- coding: utf-8 -*-
"""
main.py
Interfejs konsolowy systemu bibliotecznego.
"""
from __future__ import annotations
from typing import Optional
from biblioteka import Biblioteka
from models import Ksiazka, Czasopismo

def wczytaj_int(prompt: str) -> int:
    while True:
        val = input(prompt).strip()
        try:
            return int(val)
        except ValueError:
            print("⚠ Wpisz liczbę całkowitą.")

def menu() -> None:
    bib = Biblioteka()

    OPCJE = {
        "1": "Dodaj książkę",
        "2": "Dodaj czasopismo",
        "3": "Wypisz wszystkie pozycje",
        "4": "Szukaj po tytule",
        "5": "Wyjście",
    }

    while True:
        print("\n=== MENU BIBLIOTEKI ===")
        for k in sorted(OPCJE.keys()):
            print(f"{k}. {OPCJE[k]}")

        wybor = input("\nWybierz opcję: ").strip()

        if wybor == "1":
            tytul = input("Podaj tytuł: ").strip()
            autor = input("Podaj autora: ").strip()
            rok = wczytaj_int("Podaj rok wydania: ")
            gatunek = input("Podaj gatunek: ").strip()
            bib.dodaj_pozycje(Ksiazka(tytul=tytul, autor=autor, rok_wydania=rok, gatunek=gatunek))
            print("✅ Książka dodana!")

        elif wybor == "2":
            tytul = input("Podaj tytuł: ").strip()
            autor = input("Podaj autora: ").strip()
            rok = wczytaj_int("Podaj rok wydania: ")
            numer = input("Podaj numer (np. 8/2025): ").strip()
            bib.dodaj_pozycje(Czasopismo(tytul=tytul, autor=autor, rok_wydania=rok, numer=numer))
            print("✅ Czasopismo dodane!")

        elif wybor == "3":
            print("\n--- Wszystkie pozycje ---")
            any_printed = False
            for opis in bib.wypisz_pozycje():
                print(opis)
                any_printed = True
            if not any_printed:
                print("(pusto)")

        elif wybor == "4":
            fragment = input("Wpisz tytuł lub jego fragment: ").strip()
            wyniki = bib.znajdz_po_tytule(fragment)
            if wyniki:
                print("\n🔎 Wyniki:")
                for p in wyniki:
                    print(p.info())
            else:
                print("Brak wyników.")

        elif wybor == "5":
            print("Do zobaczenia!")
            break
        else:
            print("Nieznana opcja, spróbuj ponownie.")

if __name__ == "__main__":
    menu()
