# -*- coding: utf-8 -*-
"""
biblioteka.py
Prosta klasa zarządzająca kolekcją pozycji bibliotecznych.
"""
from __future__ import annotations
from typing import List, Iterable
from models import PozycjaBiblioteczna

class Biblioteka:
    def __init__(self) -> None:
        self._pozycje: List[PozycjaBiblioteczna] = []

    def dodaj_pozycje(self, pozycja: PozycjaBiblioteczna) -> None:
        """Dodaje pozycję do biblioteki."""
        self._pozycje.append(pozycja)

    def wypisz_pozycje(self) -> Iterable[str]:
        """Zwraca iterowalną listę opisów wszystkich pozycji (w kolejności dodania)."""
        for p in self._pozycje:
            yield p.info()

    def znajdz_po_tytule(self, tytul: str) -> List[PozycjaBiblioteczna]:
        """Zwraca listę pozycji, których tytuł zawiera podany fragment (case-insensitive)."""
        t = tytul.lower().strip()
        return [p for p in self._pozycje if t in p.tytul.lower()]
