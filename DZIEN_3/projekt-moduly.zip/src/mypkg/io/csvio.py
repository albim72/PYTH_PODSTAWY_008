import csv
from typing import Iterable, List

def read_numbers_csv(path: str, column: int = 0) -> List[float]:
    nums: List[float] = []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row:
                continue
            nums.append(float(row[column]))
    return nums

def write_numbers_csv(path: str, nums: Iterable[float]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        for x in nums:
            writer.writerow([x])
