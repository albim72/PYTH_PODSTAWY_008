import time
import re
from contextlib import contextmanager

@contextmanager
def timer(label: str):
    t0 = time.perf_counter()
    try:
        yield
    finally:
        t1 = time.perf_counter()
        print(f"[{label}] {t1 - t0:.6f}s")

_slug_re = re.compile(r"[^a-z0-9]+")
def slugify(text: str) -> str:
    return _slug_re.sub("-", text.lower()).strip("-")
