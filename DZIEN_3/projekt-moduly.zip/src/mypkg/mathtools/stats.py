from typing import Iterable, List

def mean(xs: Iterable[float]) -> float:
    xs = list(xs)
    if not xs:
        raise ValueError("empty sequence")
    return sum(xs) / len(xs)

def median(xs: Iterable[float]) -> float:
    data: List[float] = sorted(xs)
    n = len(data)
    if n == 0:
        raise ValueError("empty sequence")
    mid = n // 2
    if n % 2:
        return data[mid]
    return (data[mid - 1] + data[mid]) / 2
