from .algebra import fib
from .stats import mean, median

__all__ = ["fib", "mean", "median"]
