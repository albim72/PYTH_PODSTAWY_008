from .utils import timer
from .mathtools.algebra import fib
from .mathtools.stats import mean

def main():
    with timer("demo"):
        print("Fibonacci(10) =", fib(10))
        print("Mean[1,2,3,4] =", mean([1,2,3,4]))

if __name__ == "__main__":
    main()
