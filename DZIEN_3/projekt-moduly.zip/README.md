# mypkg
Przykład pakietu z podpakietami, modułem uruchamialnym i testami.
