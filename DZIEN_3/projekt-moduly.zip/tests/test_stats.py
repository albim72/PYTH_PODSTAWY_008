from mypkg.mathtools.stats import mean, median
import pytest

def test_mean_and_median():
    xs = [1, 2, 3, 4]
    assert mean(xs) == 2.5
    assert median(xs) == 2.5

def test_empty_raises():
    with pytest.raises(ValueError):
        mean([])
    with pytest.raises(ValueError):
        median([])
