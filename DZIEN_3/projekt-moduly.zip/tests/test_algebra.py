from mypkg.mathtools.algebra import fib
import pytest

def test_fib_small():
    assert fib(0) == 0
    assert fib(1) == 1
    assert fib(5) == 5

def test_fib_negative():
    with pytest.raises(ValueError):
        fib(-1)
