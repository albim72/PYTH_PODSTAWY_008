import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from mypkg import fib, mean, slugify

if __name__ == "__main__":
    print("fib(12) =", fib(12))
    print("mean =", mean([10, 20, 30]))
    print("slugify:", slugify("Hello, Świecie!"))
